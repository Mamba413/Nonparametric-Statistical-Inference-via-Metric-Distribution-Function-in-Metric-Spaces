void bd_gwas_test(double* stats_vec, double* permuted_stat_vec, double* pvalue_vec,
                  int* snp, int* unique_group_num_vec, int* unique_group_num_length, 
                  int* n1_num_vec, int* snp_number, double* xy, int *r, int *n,
                  int* dst, int* nthread);
