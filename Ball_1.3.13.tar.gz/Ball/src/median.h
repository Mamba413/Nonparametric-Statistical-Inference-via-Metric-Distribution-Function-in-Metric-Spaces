//
// Created by JinZhu on 2022/9/4.
//

#ifndef BALL_MEDIAN_H
#define BALL_MEDIAN_H

double find_median(double arr[], int n);

#endif //BALL_KBD_H
